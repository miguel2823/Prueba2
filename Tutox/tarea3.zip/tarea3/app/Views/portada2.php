<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="icon" href="imagenes/logo.ico">
		<title>Falabella</title>

		<!-- Bootstrap core CSS -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

		<!-- Custom styles for this template -->
		<link href="starter-template.css" rel="stylesheet">
 		<link rel="stylesheet" href="<?php echo base_url();?>/resources/css/estilo.css">

	</head>

	<body>
		 <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
			<img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBhUPEg4PDxASFxUVEBYQDQ8PDRIWFxMWFxUSExUYKDQgGRolJxUTJjEhKSkrLi4uGR8zODMtNygwLisBCgoKDg0OGxAQGC0fIB8uLzctLS0tLzctLSsvLSstNystKy0tKzAtLS0tLS0tLS0tLSstLS0tLS0tLS0rLS0tOP/AABEIAOEA4QMBEQACEQEDEQH/xAAbAAEBAQEBAQEBAAAAAAAAAAAABgUEAwcBAv/EADYQAQABAgMDCgUDBAMAAAAAAAABAgMEBRESIVEGEzFBUmFxgaHBFCKRsdGCkuFUwvDxNEJi/8QAGwEBAAIDAQEAAAAAAAAAAAAAAAIGAQUHBAP/xAAvEQEAAQMCBAUCBQUAAAAAAAAAAQIDBAUREhMhUQYxQWGxkfAUU4HB8TIzQlJx/9oADAMBAAIRAxEAPwCrcwQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAemHw97E3Nmimap7o6PHg+1nHuXquG3TvI0pyOuzRrdvWrWvGdZbOdGqt073rlNDOzixmGs4eI2b9F3XsxMTHi8WVjW7URNFyK9+xLmeNgAAAAAAAAAAAAAAAAAAAAAAAB15XgLmYYjZjdTG+ueEfl7sDBryrnDHSI85IjdU4irD5Ll0zTTG7dTHXVVPGVuvVWtOx5miP+e8p+SPxF+5ib011TtVT/mkdykXr9d6ua653mUHm+QAAAAAAAAAAAAAAAAAAAAAAAAAt8lwcYLAUxp80/NX4z1eXQv+mYsY9iI9Z6ynDG5W39q/Rb7MbU+M7o+0/Vo/EN7eum126oywVcYAAAAAAAAAAAAAAAAAAAAAAAAAdWV2Picwoo6pnWfCN8/Z7NPs83Jop9/ghduhJofOr3PZpXPVE7MfpjT2lQdUu8zKrnt0QnzcTXgAAAAAAAAAAAAAAAAAAAAAAAADb5KWtrHVVdmn1mY/Et/4ftcV+qufSPlmlUXa4t2pqnoiJmfKFtuVcFE1T6Qk+e11TXXM9czMz5ua3KuKqau6D8RAAAAAAAAAAAAAAAAAAAAAAAAAFTyStbOEqr7VWnlEfzK3+H7W1mqvvPwlDtz27zOVVzxjZ/dMR7vfqt3l4tc9+n1ZlEqCgAAAAAAAAAAAAAAAAAAAAAAAAAAtsitczlVEcY2v3Tr7r9pdvl4tEd43Shw8rbuzhaKO1Vr5RH8w1/iG5tZpo7ySl1RRAAAAAAAAAAAAAAAAAAAAAAAAAftNM11REdM7o80qKeKqKe4+hWqIt24pjoiIj6Q6Tbp4aIp7JpblXd28fTT2afWZ/iFS8QXOK/TR2j5RlitCwAAAAAAAAAAAAAAAAAAAAAAAAA7Mms8/mdEd+s+W/wBnv0y1zMqiPdmFy6Akhs4u89mdyr/1pH6d3s59qV3mZVc+6E+bjeEAAAAAAAAAAAAAAAAAAAAAAI0139HWlTtvG/kNyMXkUR/x6/X8t/GTpe39ufv9Wd4Pi8i/p6/X8s/idL/K+/qbw0clqy2/fmq1amiqmN8z39Ub+5stMqw7lc1WKNpj92Ya12um1amqeiImZ8obiuuKKZqn0ZTE4zI6p1+Hr1nfPT+VWqy9Mmd5tz9/qjvB8XkX9PX6/lH8Tpf5X39TeHnfxWTTZnZw9W1pOzrrpr1a70L2Tp3BPBa6+hvDHaFgAAAAAAAAAAAAAAAAAAAAAABVck7Wzgqq+1V6RH+1x8P2uGxNXefhKHXn93mcqr4zpTHnOk+72atd5eJVPfozKKUJAAAAAAAAAAAAAAAAAAAAAAAAAABc5Na5nLKI69nWfGd/u6Dp1rl41FPsnDM5XXdLFFHGZq+kaf3NV4iu7W6KO87/AE/liUyqaIRG4rcDkGFt2I5ynbrmPm3zER3RoumJotii3HMjimfNLZjZ9llOAuxNOuxVrpEzrNMx1atHq2n04tUVUf0z8sTDLadgAAAAAAAAAAAAAAAAAAAAB/Vm3N27FPamI+s6PpZo47lNPeSH0OmIpp04Ok0xwxER6JpLlTd28y2exTEec7/wp2vXeLIintCMsdo2DoZidp3Flgc7wl+xE1V00Vf9oqnTf3cYXjE1bHu24mqrafWJS3YnKHMreNuU00TrTTrv001meHc0Os6hRkVRRb6xHr7sTLIaRgAAAAAAAAAAAAAAAAAAAABoZBa57NaOFOtU+UbvXRs9HtczLp9urMea2XxJBZnd5/MK6uNU6eEbo+znefd5mRXV7oT5uZ5AAAAAAAAAAAAAAAAAAAAAAAAABv8AJK1rfrr4RER5zrP2hY/DtreuuvszChxd3mMLVX2aZn6Qs2Rc4LVVXaEnz9zeZ3ndAYAAAAAAAAAAAAAAAAAAAAAAAAAFbyWs7GW7XbqmfKNI9pXTQrXDjcU/5SlD15SXeayqqO1MU+us/aX11q7wYtXv0J8kaoyIAAAAAAAAAAAAAAAAAAAAAAAAD8Be5ZZ5jL6KeFMa+M75dEwrXLx6KfZNjcrru63R41T6RH3lo/EV3pRbj3lipOKuiAAAAAAAAAAAAAAAAAAAAAAAAA9cJa5/FUUdqqmPKZ3vvi2+Zeppj1mB9AiNzo8RtGyaO5S3eczWY7MRT7+6k65d48qY/wBY2RlltOwAAAAAAAAAAAAAAAAAAAAAAAAA0+Tdnnc1pnqpiavTSPu2+iWuPKie3VmFlMxEarvM7Ruk+f4q98Riaq+1Mz67nOMm7zbtVfeUHk+AAAAAAAAAAAAAAAAAAAAAAAAAApuSWH2bVdyeuYpjwjp+/otfh6xtRVdn16JQ7s/xcYXLqt/zV/LTx39M/RsNWyYsY896ukEotREQAAAAAAAAAAAAAAAAAAAAAAAAHrhcPcxV+KKY1mfpHfPc++Pj137kUUR5i1icPlWAiJnSmiPOZ7o4yvcTawseIqnaKYTSGaY+5mGJ2p3RG6iOEflS8/NqyrvFPlHlCEzu5HhAAAAAAAAAAAAAAAAAAAAAAAAHRg6sJTXPO011RpuiiYide96sWrHpmefTMx6bENKjOrGEt6WcPFGvXVOs+fXP1bWnV7VinbHtbe8s7svF4u/jLm1XVNU9XVTHhHU1GRlXciriuTuxu8XnAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH//Z" alt="">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarsExampleDefault">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item active">
						<a class="nav-link" href="index.php">Inicio <span class="sr-only">(current)</span></a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="pagina1.php">Electrodomestico</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link " href="pagina3.php">Muebles</a>
					</li>
					<li class="nav-item dropdown active">
						<a class="nav-link dropdown-toggle" href="http://example.com" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Tecnologia</a>
						<div class="dropdown-menu" aria-labelledby="dropdown01">
							<a class="dropdown-item" href="#">Celular</a>
							<a class="dropdown-item" href="#">Laptop</a>
							<a class="dropdown-item" href="#">Televisor</a>
						</div>
					</li>
				</ul>
				<form class="form-inline my-2 my-lg-0">

					<input class="form-control mr-sm-2" type="text" placeholder="Busqueda" aria-label="Search">
					<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Busqueda</button>
				</form>
			</div>
		</nav>
 		
		<!-- carrusel de imagenes-->
	<section>
			<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner" role="listbox">

    <div class="carousel-item active">
      <img class="d-block img-fluid" src="https://falabella.scene7.com/is/image/FalabellaPE/060920-hs-hh-video?hei=490&fmt=webp&qlt=85&cache=off&vid=1 1680w,https://falabella.scene7.com/is/image/FalabellaPE/060920-hs-hh-video?hei=980&fmt=webp&qlt=85&cache=off&vid=1 3360w" alt="First slide">
    </div>

    <div class="carousel-item">
      <img class="d-block img-fluid" src="https://falabella.scene7.com/is/image/FalabellaPE/060920-hs-hh-zapatillas?hei=490&qlt=85&cache=off&vid=2 1680w,https://falabella.scene7.com/is/image/FalabellaPE/060920-hs-hh-zapatillas?hei=980&qlt=85&cache=off&vid=2 3360w" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block img-fluid" src="https://falabella.scene7.com/is/image/FalabellaPE/060920-hs-hh-computadoras?hei=490&fmt=webp&qlt=85&cache=off&vid=2 1680w,https://falabella.scene7.com/is/image/FalabellaPE/060920-hs-hh-computadoras?hei=980&fmt=webp&qlt=85&cache=off&vid=2 3360w">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<div class="container">
			<!-- Example row of columns -->
			<div class="row">
				<div class="col-md-4">
					<img src="https://falabella.scene7.com/is/image/FalabellaPE/060920-hs-promoted-zapatillas-aldo?hei=320&qlt=85&cache=off&v=1" alt="">
				</div>
				<div class="col-md-4">
					<img src="https://falabella.scene7.com/is/image/FalabellaPE/060920-sxh-b2-3-app?scl=1&cache=off&v=3" alt="">
				</div>
				<div class="col-md-4">
					<img src="https://falabella.scene7.com/is/image/FalabellaPE/060920-hs-promoted-celular?hei=320&qlt=85&cache=off&v=1" alt="">
				</div>
					<div class="col-md-4">
					<img src="https://falabella.scene7.com/is/image/FalabellaPE/060920-hs-promoted-movilidad?hei=320&qlt=85&cache=off&v=1 630w,https://falabella.scene7.com/is/image/FalabellaPE/060920-hs-promoted-movilidad?hei=640&qlt=85&cache=off&v=1 1270w" alt="">
				</div>
				<div class="col-md-4">
					<img src="https://falabella.scene7.com/is/image/FalabellaPE/060920-hs-promoted-infantil?hei=320&qlt=85&cache=off&v=1" alt="">
				</div>
				<div class="col-md-4">
					<img src="https://falabella.scene7.com/is/image/FalabellaPE/060920-hs-promoted-muebles?hei=320&qlt=85&cache=off&v=1" alt="">
				</div>
			

			</div>
			<hr>
			<div class="ubicacion">
				 <h1><span class="badge badge-dark">UBICANOS</span></h1>
			
				
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7805.441953869229!2d-77.06288722463376!3d-11.993798714253256!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x5b3c1b69a9eced7f!2sSaga%20Falabella!5e0!3m2!1ses!2spe!4v1599451462701!5m2!1ses!2spe" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
			</div>
			
	<hr>
			<div class="row">
				<div class="col-md-2">
					<div></div>
				</div>
			<div class="col-md-8">
					<div class="card" style="width: 100%;height: 100%;">
					  <div class="card-body">
					  	<?php $validation = \Config\Services::validation(); ?>
      				    <?= form_open('Portada/doSave', array('id' => 'frmreg','name' => 'frmreg')) ?>
					    <h2 class="text-center">INSCRIPCIÓN</h2>
					
						  <div class="form-row">
						    <div class="form-group col-md-6">
						      <label for="nombre">Nombre :</label>
							  <input type="text" class="form-control" id="nombre"
							   name="nombre" title="Solo alfanumericos" placeholder="Ingresar Nombre" required>
						    </div>
						    <div class="form-group col-md-6">
							    <label for="apellidos">Apellidos :</label>
	    						<input type="text" class="form-control" id="apellidos"
	 							name="apellidos" title="Solo alfanumericos" placeholder="Ingresar Apellidos" required>
						    </div>
						  </div>
						  <div class="form-group">
						    <label for="correo">Correo :</label>
    						<input type="email" class="form-control" id="correo"
 							name="correo" title="Formato correo" placeholder="Ingresar Correo" required>
						  </div>
						  <div class="form-row">
						    <div class="form-group col-md-6">
						      <label for="fecha">Dirección :</label>
    						  <input type="text" class="form-control" id="dir"
 							   name="dir" title="Solo alfanumericos" placeholder="Ingresar Direccion" required>
						    </div>
						    <div class="form-group col-md-6">
    						  <label for="tel">Teléfono :</label>
    						  <input type="text" class="form-control" id="tel"
   							  name="tel" title="Solo digitos" placeholder="Ingresar Telefono">
						    </div>
						  </div>
						  
						  <div class="form-row">
						    <div class="form-group col-md-6">
						      <label for="fecha">Fecha Nacimiento :</label>
    						  <input type="date" class="form-control" id="fecha"
 							   name="fecha" title="Formato Fecha" placeholder="Ingresar Fecha Nacimiento" required>
						    </div>
						    <div class="form-group col-md-6">
						      <label for="dni">DNI :</label>
    						  <input type="text" class="form-control" id="dni"
   							  name="dni" title="Solo digitos" placeholder="Ingresar DNI">
						    </div>
						    </div>
						    <div class="form-group">
						    	<label for="sexo">Sexo :</label>
								 <select name="sexo" id="sexo" class="custom-select">
							    <option selected>eliga</option>
							    <option value="0">Femenimo</option>
							    <option value="1">Masculino</option>
							      </div>
							  </select>
						  </div>
						    <div class="form-group">

						  <button type="submit" class="btn btn-primary form-control">REGISTRAR</button></div>
						</form>
					  </div>
					</div>
					
				</div>
				<div class="col-md-2">
					<div></div>
				

			</div>
	</section>
			<hr>
	
			
	
	
		</div> <!-- /container -->
	<footer>
				<p>&copy;Peru 2020</p>
			</footer>
		


		<!-- Bootstrap core JavaScript ================================================== -->
		<!-- Placed at the end of the document so the pages load faster -->
		<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
		<script src="../../../../assets/js/ie10-viewport-bug-workaround.js"></script>
	</body>
</html>